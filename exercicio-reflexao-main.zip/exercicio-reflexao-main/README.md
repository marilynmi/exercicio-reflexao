# Seleção Bolsista FAPESP
# Projeto: Um Estudo sobre o Impacto de Anotações de Código na Evolução de Software

Exercício Sobre Reflexão

Instruções para a Entrega:

* Clonar esse repositório
* Implementar a sua solução (todos os testes devem passar)
* Colocar a sua solução completa em algum repositório Git público
* Enviar o link do seu repositório para: paulo.meirelles@unifesp.br ; phyllipe@inatel.br ; eduardo.guerra@unibz.it

Resumo da atividade:
* Criar e implementar a classe AnnotationReader
* Criar a anotação @NumberToSum


