package br.inatel.cdg.annotation.reading;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

//Nessa classe você deverá implementar a sua solução
//Adicionalmente você também deverá criar
//a anotação NumberToSum como parte da solução

public class AnnotationReader<T> {	
	
	private int TotalSum; //storage sum of the parameters values in annotations
	private Class<?> dataClass; // instance of classes ExampleClass1 and ExampleClass2
	
	//Constructor with generic parameter class
	public AnnotationReader(Class<?> clazz) {
		
		this.dataClass = clazz;
		this.TotalSum = 0;
	}
	
	public void readAnnotations() {
		
		//Get annotations in the Fields
		Field listaCampo[] = this.dataClass.getDeclaredFields(); // array to get Fields with annotations
		
		//Get annotation in the Methods
		Method listMethod[] = this.dataClass.getDeclaredMethods(); // array to get Method with annotations

		//Read annotation values in the variables
		for (Field field : listaCampo) {
			java.lang.annotation.Annotation[] annotations = field.getAnnotations();			
			
			for (java.lang.annotation.Annotation a : annotations) {
				
				for (Method m : a.annotationType().getDeclaredMethods()) {
					
					//Object to invoke annotation values
					Object o = null;
					//Exception of Object om variable
					try {
						o = m.invoke(a);
						
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println("Valor: " + o.toString());
					this.setTotalSum(Integer.parseInt((o.toString())));
				}
			}			
		}
		
		//Read annotation values in the Method
		for (Method method : listMethod) {
			
			java.lang.annotation.Annotation[] annotationsM = method.getAnnotations();
			for (java.lang.annotation.Annotation am : annotationsM) {
								
				for (Method m2 : am.annotationType().getDeclaredMethods()) {
					
					//Object to invoke annotation values
					Object om = null;
					
					//Exception of Object om variable
					try {
						om = m2.invoke(am);
						
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//Sum annotation value and storage in the TotalSum variable
					this.setTotalSum(Integer.parseInt((om.toString())));
				}
				
			}
			
		}
	
	}
	
	//Set sum of annotation values
	protected void setTotalSum(int TotalSum) {		
		this.TotalSum = this.TotalSum + TotalSum;		
	}
	
	//Get sum of annotation values
	public int getTotalSum() {
		return this.TotalSum;
	}

}